//
//  MovieNavigationController.m
//  P2PCamera
//
//  Created by CHENCHAO on 13-7-10.
//  Copyright (c) 2013年 CHENCHAO. All rights reserved.
//

#import "MovieNavigationController.h"



@implementation MovieNavigationController

- (id)init
{
    
    if (self = [super init])
    {
       
    }
    return self;
}

-(BOOL)shouldAutorotate
{
    return NO;
}

@end
