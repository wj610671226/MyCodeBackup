//
//  ANNavigationController.m
//
//  IpCamera
//  Created by chenchao on 13-5-23.
//  Copyright (c) 2013年 CHENCHAO. All rights reserved.
//


#import "ANNavigationController.h"



@implementation ANNavigationController

- (id)init
{

    if ( self = [super init])
    {
        
    }
    return self;
}
- (BOOL)shouldAutorotate
{
    return YES;
}



@end
