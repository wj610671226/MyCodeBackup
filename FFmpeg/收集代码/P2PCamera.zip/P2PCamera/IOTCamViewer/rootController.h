//
//  rootController.h
//  IOTCamViewer
//
//  Created by 百堅 蕭 on 12/4/24.
//  Copyright (c) 2012年 Throughtek Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface rootController : UITabBarController 

@end
