//
//  RootNavigationController.m
//  P2PCamera
//
//  Created by CHENCHAO on 13-10-11.
//  Copyright (c) 2013年 CHENCHAO. All rights reserved.
//

#import "RootNavigationController.h"



@implementation RootNavigationController

- (id)init
{
    
    if ( self = [super init])
    {
        
    }
    return self;
}
- (void)dealloc
{
    [super dealloc];
    
}
- (BOOL)shouldAutorotate
{
    return NO;
}


@end
