//
//  RootNavigationController.h
//  P2PCamera
//
//  Created by CHENCHAO on 13-10-11.
//  Copyright (c) 2013年 CHENCHAO. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootNavigationController : UINavigationController
{
    
}

@end
