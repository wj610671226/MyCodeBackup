//
//  PopupNavigationController.h
//  P2PCamera
//
//  Created by CHENCHAO on 13-9-24.
//  Copyright (c) 2013年 CHENCHAO. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PopupNavigationController : UINavigationController
{
    
}

@end
