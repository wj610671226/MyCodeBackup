//
//  PopupNavigationController.m
//  P2PCamera
//
//  Created by CHENCHAO on 13-9-24.
//  Copyright (c) 2013年 CHENCHAO. All rights reserved.
//

#import "PopupNavigationController.h"



@implementation PopupNavigationController

- (id)init
{
    self = [super init];
    if (self) {

    }
    return self;
}


- (BOOL)shouldAutorotate
{
    return YES;
}

@end
