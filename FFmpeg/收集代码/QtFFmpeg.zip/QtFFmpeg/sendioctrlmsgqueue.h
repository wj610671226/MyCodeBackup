#ifndef SENDIOCTRLMSGQUEUE_H
#define SENDIOCTRLMSGQUEUE_H

extern "C" {
#include <stdbool.h>
#include <pthread.h>
#include <stdlib.h>
#include <memory.h>
}

#define QUEUE_SIZE 32
#define MAX_IOCTRL_BUFFER_SIZE 1024


typedef struct IOCtrlMsgQueue{
    int type;
    char buffer[MAX_IOCTRL_BUFFER_SIZE];
    int buffer_size;

}IOCtrlMsgQueue_t;

class SendIOCtlMsgQueue
{
public:
    SendIOCtlMsgQueue();
    ~SendIOCtlMsgQueue();

private:

    int front;
    int rear;
    IOCtrlMsgQueue_t *sendIOCtrlMsgQueue;

    pthread_mutex_t  msg_locker;

public:

    bool IOCtrlMsgQueueIsEmtpy();
    int enqueueIOCtrlMsg(int type ,char* buffer,int buffer_size);
    int dequeueIOCtrlMsg(int *type,char* buffer,int * buffer_size);

};


#endif // SENDIOCTRLMSGQUEUE_H
