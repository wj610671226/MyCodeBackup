#include "sendioctrlmsgqueue.h"


SendIOCtlMsgQueue::SendIOCtlMsgQueue()
{
    sendIOCtrlMsgQueue = (IOCtrlMsgQueue_t *)malloc(QUEUE_SIZE * sizeof(IOCtrlMsgQueue_t));

    memset(sendIOCtrlMsgQueue, 0, QUEUE_SIZE * sizeof(IOCtrlMsgQueue_t));
    front = rear = 0;

    pthread_mutex_init (&msg_locker,NULL);
}

SendIOCtlMsgQueue::~SendIOCtlMsgQueue()
{
    if (sendIOCtrlMsgQueue)
    {
        free(sendIOCtrlMsgQueue);
    }

    for (int i = 0; i < QUEUE_SIZE; i++) {

        sendIOCtrlMsgQueue[i].type = 0;
        sendIOCtrlMsgQueue[i].buffer_size = 0;

        memset(sendIOCtrlMsgQueue[i].buffer, 0, MAX_IOCTRL_BUFFER_SIZE);
    }

}


bool SendIOCtlMsgQueue::IOCtrlMsgQueueIsEmtpy()
{
    return front == rear;
}
int SendIOCtlMsgQueue::enqueueIOCtrlMsg(int type ,char* buffer,int buffer_size)
{

    int r = (rear + 1) % QUEUE_SIZE;

    if (front == r) {

        return 0;
    }

    pthread_mutex_lock(&msg_locker);

    memset(sendIOCtrlMsgQueue[r].buffer, 0, MAX_IOCTRL_BUFFER_SIZE);

    sendIOCtrlMsgQueue[r].type = type;
    sendIOCtrlMsgQueue[r].buffer_size = buffer_size;
    memcpy(sendIOCtrlMsgQueue[r].buffer, buffer, buffer_size);

    rear = r;
    pthread_mutex_unlock(&msg_locker);
    return 1;
}
int SendIOCtlMsgQueue::dequeueIOCtrlMsg(int *type,char* buffer,int * buffer_size)
{

    int f;
    if (front == rear)
        return 0;

    f = (front + 1) % QUEUE_SIZE;

    pthread_mutex_lock(&msg_locker);

    *type = sendIOCtrlMsgQueue[f].type;
    *buffer_size = sendIOCtrlMsgQueue[f].buffer_size;
    memcpy(buffer, sendIOCtrlMsgQueue[f].buffer, sendIOCtrlMsgQueue[f].buffer_size);

    memset(sendIOCtrlMsgQueue[f].buffer, 0, MAX_IOCTRL_BUFFER_SIZE);
    sendIOCtrlMsgQueue[f].buffer_size = 0;
    sendIOCtrlMsgQueue[f].type = 0;

    front = f;

    pthread_mutex_unlock(&msg_locker);

    return 1;
}


