#ifndef DECODEH264DATA_YUV_H
#define DECODEH264DATA_YUV_H
#pragma pack(push, 1)


typedef struct H264FrameDef
{
    unsigned int    length;
    unsigned char*  dataBuffer;

}H264Frame;

typedef struct  H264YUVDef
{
    unsigned int    width;
    unsigned int    height;
    H264Frame       luma;
    H264Frame       chromaB;
    H264Frame       chromaR;

}H264YUV_Frame;

typedef struct RGBDataDef
{
    unsigned int    width;
    unsigned int    height;
    unsigned int    bufferSize;
    unsigned char*  dataBuffer;
    
}RGBData;


#pragma pack(pop)


#endif // DECODEH264DATA_YUV_H
