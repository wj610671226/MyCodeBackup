#include "cameraclient.h"

extern "C" {
#include <sys/time.h>
#include <unistd.h>
#include <memory.h>
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#import "IOTCAPIs.h"
#import "AVAPIs.h"
#import "AVIOCTRLDEFs.h"
#import "AVFrameInfo.h"

}


CameraClient::CameraClient(char *uid_ ,char * name_ ,char * viewAcc_ ,char *viewPwd_)
{

    memcpy(name,name_,sizeof(name));
    memcpy(uid,uid_,sizeof(uid));
    memcpy(viewAcc,viewAcc_,sizeof(viewAcc));
    memcpy(viewPwd,viewPwd_,sizeof(viewPwd));

    sessionID               =-1;
    sessionMode             =-1;
    sessionState            =-1;
    sessionID4ConnStop      =-1;

    audioCodec              =-1;
    nAvResend               =-1;
    avIndex                 =-1;

    avChannel               =0;

    connFailErrCode         =0;
    connectionState         =0; //连接状态.
    chIndexForSendAudio     =0; //发送Audio通道。
    avIndexForSendAudio     =0; //sendAudio index


    isRunningRecvVideoThread        =false;
    isRunningSendIOCtrlThread       =false;
    isRunningRecvIOCtrlThread       =false;
    isConnectingServer              =false;
    isRunningSendAudio              =false;

    //初始化消息队列.
    iocontrollMsgQueue=new SendIOCtlMsgQueue();



}

CameraClient::~CameraClient()
{
    if(iocontrollMsgQueue){
        delete iocontrollMsgQueue;
        iocontrollMsgQueue=NULL;
    }

}


void CameraClient::initIOTC()
{

    printf("\n\n=======avInitialize=====================\n\n");
    unsigned short nUdpPort = (unsigned short)(10000 + (getTickCount() % 10000));
    int ret = -1;

    ret=IOTC_Initialize(nUdpPort, "50.19.254.134", "122.248.234.207", "46.137.188.54", "122.226.84.253");

    if (ret < 0)
    {
        printf("IOTC_Initialize2() failed -> %d", ret);
    }

    avInitialize(160);
   printf("\n\n=======avInitialize END=====================\n\n");

}

void CameraClient::uninitIOTC()
{
    printf("\n\n===============avDeInitialize===========");
    avDeInitialize();
    IOTC_DeInitialize();
    printf("=======avDeInitialize ENd=====================\n\n");
}


void CameraClient::connect()
{

    detachThreadCreate(NULL,(void*)doStartThread,this);
}
void* CameraClient::doStartThread(void* arg)
{
    CameraClient* camClient=(CameraClient*)arg;
    if(camClient!=NULL){
        camClient->startConnection();
    }
    
    return NULL;
}
void CameraClient::startConnection()
{
    printf("StartName: %s UID: %s Account: %s Password: %s\n",name, uid,viewAcc,viewPwd);
    int reConnectCount=0;

RECONNECT_POINT:

    isConnectingServer=true;

    int serverType = 0;
    int sid = -1;

    if(sessionID < 0)
    {

        sessionID4ConnStop = IOTC_Get_SessionID();

        char* buffer=(char*)malloc(sizeof(char)*20);
        memcpy(buffer, uid, sizeof(uid));
        sid = IOTC_Connect_ByUID_Parallel(buffer, sessionID4ConnStop);

        printf("!!!!!!!!!!!!!!!!!!!!!!!!!!SessionID4Stop:%d SID: %d UID: %s\n",sessionID4ConnStop,sid,buffer);

        if (sid >= 0)
        {
            sessionID = sid;

            struct st_SInfo Sinfo;
            int ret;

            ret = IOTC_Session_Check(sid, &Sinfo);

            if(Sinfo.Mode == 0){
                sessionMode = CONNECTION_MODE_P2P;
            }
            else if(Sinfo.Mode == 1){
                sessionMode = CONNECTION_MODE_RELAY;
            }
            else if(Sinfo.Mode == 2){
                sessionMode = CONNECTION_MODE_LAN;
            }


        }
        else if (sid == IOTC_ER_UNLICENSE || sid == IOTC_ER_UNKNOWN_DEVICE || sid == IOTC_ER_CAN_NOT_FIND_DEVICE)
        {
            connFailErrCode = sid;
        }
        else if (sid == IOTC_ER_TIMEOUT)
        {
            connFailErrCode = sid;

        }
        else if (sid == IOTC_ER_CONNECT_IS_CALLING)
        {
            connFailErrCode = sid;
            connectionState = CONNECTION_STATE_CONNECT_FAILED;
        }
        else
        {
            connFailErrCode = sid;
        }

        if(buffer!=NULL)
        {
            free(buffer);
        }

    }

    if(sessionID>=0)
    {

        if (avIndex < 0)
        {

            printf("SessionID: %d Account: %s Password: %s\n",sessionID,viewAcc,viewPwd);

            avIndex = avClientStart2(sessionID, (char *)viewAcc, (char *)viewPwd, 30, (unsigned long *)&serverType, avChannel, &nAvResend);


            printf("Name: %s ConnectionState: %d avIndex: %d",name,connectState,avIndex);

            if (avIndex >= 0)
            {


            } else if (avIndex == AV_ER_WRONG_VIEWACCorPWD)
            {

            } else if (avIndex == AV_ER_REMOTE_TIMEOUT_DISCONNECT || avIndex == AV_ER_TIMEOUT)
            {
            }

        }


    }
    else
    {
        //session id<=0;
    }
    //发送接受Msg线程.
    if((sessionID>=0)&&(avIndex>=0))
    {
        isRunningSendIOCtrlThread=true;
        isRunningRecvIOCtrlThread=true;
        printf("=================Connect Sucess!!!!!============================");
        detachThreadCreate(NULL,(void*)startSendIOCtrlFromMsgQueueThread,this);
        detachThreadCreate(NULL,(void*)startRecvIOCtrlFromDeviceThread,this);

        sleep(2);

        startShow();

    }
    else if((sessionID<0)||(avIndex<0))
    {
        if(reConnectCount++<3)
        {
                goto RECONNECT_POINT;
        }

    }

    isConnectingServer=false;
}



void CameraClient::stopConnectedSession()
{

}


void CameraClient::startShow()
{
     printf("=================Start Video============================");
    int camIndex = 0;

    sendIOCtrl(IOTYPE_INNER_SND_DATA_DELAY,(char *)&camIndex,4);
    sendIOCtrl(IOTYPE_USER_IPCAM_START,(char *)&camIndex,4);

    isRunningRecvVideoThread=true;
    updatingYUVFrame=true;
    detachThreadCreate(NULL,(void*)startRecvVideoThread,this);

}
void* CameraClient::startRecvVideoThread(void* arg)
{
    CameraClient* camClient=(CameraClient*)arg;
    if(camClient!=NULL){
        camClient->doRecvVideo();
    }
     return NULL;
}
void CameraClient::doRecvVideo()
{
    int readSize = -1;
    char *recvBuf =(char *) malloc(RECV_VIDEO_BUFFER_SIZE);

    FRAMEINFO_t frmInfo = {0};
    unsigned int frmNo = 0,prevFrmNo=0x0FFFFFFF;


    int outBufSize = 0, outFrmSize = 0, outFrmInfoSize = 0;

    unsigned int timestamp=getTickCount();

    int videoBps=0;

    H264Decoder* decoder=new H264Decoder();

    if (sessionID >= 0 && avIndex >= 0)
    {

        avClientCleanVideoBuf(avIndex);


        while (isRunningRecvVideoThread)
        {


            unsigned int now = getTickCount();

            if (now - timestamp > 1000)
            {

                timestamp = now;
                videoBps = 0;
            }

            usleep(1*1000);


            readSize = avRecvFrameData2(avIndex, recvBuf, RECV_VIDEO_BUFFER_SIZE, &outBufSize, &outFrmSize, (char *)&frmInfo, sizeof(frmInfo), &outFrmInfoSize, &frmNo);
            //printf("recv Video: %d",readSize);

            if (readSize == AV_ER_BUFPARA_MAXSIZE_INSUFF)
            {

                continue;

            }else if (readSize ==  AV_ER_MEM_INSUFF)
            {
                continue;
            } else if(readSize == AV_ER_INCOMPLETE_FRAME)
            {
                continue;
            }
            else if (readSize == AV_ER_LOSED_THIS_FRAME)
            {
                continue;
            }
            else if (readSize == AV_ER_DATA_NOREADY)
            {
                usleep(10*1000);
                continue;

            }
            else if (readSize >= 0)
            {
                if (frmInfo.flags == IPC_FRAME_FLAG_IFRAME || frmNo == (prevFrmNo + 1))
                {

                    prevFrmNo = frmNo;
                    if (frmInfo.codec_id == MEDIA_CODEC_VIDEO_H264)
                    {
                        //printf("RECV H.264 ======================size: %d\n",readSize);
                        //[[Mp4VideoRecorder getInstance] writeFrameData:(unsigned char *)recvBuf withSize:readSize];


                        RGBData* rgbData=new RGBData();
                        
                        decoder->DecodeH264Frames((unsigned char*)recvBuf,readSize,rgbData);
                        
                        updateImageData(rgbData);
                        
                        delete rgbData;

                    }
                    videoBps+=readSize;
                }
                else
                {
                    printf("[H264] Incorrect Framedrop frame:%d %d\n",frmNo,prevFrmNo);
                    usleep(1*1000);
                    continue;
                }


            }
            else
            {
                usleep(1*1000);
                continue;

            }


        }

    }
    else
    {
        free(recvBuf);

        printf("doRecvVideo: [sessionID < 0 || avIndex < 0]\n");
        return;
    }

    free(recvBuf);

    if(decoder){
        delete decoder;
    }

    printf("\t=== RecvVideo Thread Exit ===\n");


}

void CameraClient::stopShow()
{
    isRunningRecvVideoThread=false;
    updatingYUVFrame=false;

    int camIndex = 0;
    sendIOCtrl(IOTYPE_USER_IPCAM_STOP,(char *)&camIndex,4);

}

void CameraClient::startSoundToPhone()
{

}

void CameraClient::stopSoundToPhone()
{

}

void CameraClient::startSoundToDevice()
{

}

void CameraClient::stopSoundToDevice()
{

}


void* CameraClient::startSendIOCtrlFromMsgQueueThread(void* arg)
{

    CameraClient* camClient=(CameraClient*)arg;
    if(camClient!=NULL){
        camClient->sendIOCtrlThread();
    }
     return NULL;
}

void CameraClient::sendIOCtrl(int controlCMD ,char * buff,int size)
{
    iocontrollMsgQueue->enqueueIOCtrlMsg(controlCMD,buff,size);
}


void CameraClient::sendIOCtrlThread()
{
     printf("=================Start Send IO Controll============================");

     int type, size;
     char *buff =(char *) malloc(MAX_IOCTRL_BUFFER_SIZE);

     while (isRunningSendIOCtrlThread)
     {
         while (isRunningSendIOCtrlThread && (sessionID < 0 || avIndex < 0)) {
             usleep(1 * 1000);
             continue;
         }

         if (sessionID >= 0 && avIndex >= 0)
         {

             if(iocontrollMsgQueue->dequeueIOCtrlMsg(&type,buff,&size))
             {
                 bool bRetry = false;
                 do
                 {
                     bRetry = false;


                     int nRet = avSendIOCtrl(avIndex, type, buff, size);

                     switch(nRet)
                     {
                         case AV_ER_INVALID_ARG:
                         {

                         }   break;
                         case AV_ER_SENDIOCTRL_ALREADY_CALLED:
                         {
                             bRetry = true;
                             usleep( 1*1000 );
                         }   break;
                         case AV_ER_SESSION_CLOSE_BY_REMOTE:
                         {

                         }   break;
                         case AV_ER_REMOTE_TIMEOUT_DISCONNECT:
                         {

                         }   break;
                         case AV_ER_INVALID_SID:
                         {

                         }   break;
                         case AV_ER_SENDIOCTRL_EXIT:
                         {

                         }   break;
                         case AV_ER_EXCEED_MAX_SIZE:
                         {

                         }   break;

                         case AV_ER_NoERROR:
                         default:
                             break;
                     }
                 } while (bRetry);

             }
         }

         usleep(1 * 1000);
     }

     free(buff);


}

void* CameraClient::startRecvIOCtrlFromDeviceThread(void* arg)
{
    CameraClient* camClient=(CameraClient*)arg;
    if(camClient!=NULL){
        camClient->recvIOCtrlThread();
    }
    return NULL;

}

void CameraClient::recvIOCtrlThread()
{
}


void CameraClient::updateImageData(RGBData* rgbData)
{
    if((rgbData->dataBuffer!=NULL)&&(rgbData->bufferSize>0))
    {
        update2GUICallback(rgbData,m_userData);
    }
}


unsigned int CameraClient::getTickCount() {

    struct timeval tv;

    if (gettimeofday(&tv, NULL) != 0)
        return 0;

    return (tv.tv_sec * 1000 + tv.tv_usec / 1000);
}
int CameraClient::detachThreadCreate(pthread_t *thread, void * start_routine, void *arg)
{
    pthread_attr_t attr;
    pthread_t thread_t;
    int ret = 0;

    if(thread==NULL){
        thread = &thread_t;
    }
    //初始化线程的属性
    if(pthread_attr_init(&attr))
    {
        printf("pthread_attr_init fail!\n");
        return -1;
    }

    //设置线程detachstate属性。该表示新线程是否与进程中其他线程脱离同步
    if(pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED))
    {//新线程不能用pthread_join()来同步，且在退出时自行释放所占用的资源。
        printf("pthread_attr_setdetachstate fail!\n");
        goto error;
    }

    ret = pthread_create(thread, &attr, (void *(*)(void *))start_routine, arg);
    if(ret < 0){
        printf("pthread_create fail!\n");
        goto error;
    }

    //将状态改为unjoinable状态，确保资源的释放。
   ret =  pthread_detach(thread_t);

error:
    pthread_attr_destroy(&attr);

    return ret;
}
void CameraClient::setupUpdateGUICallback(UPDATEVIDEO2GUICALLBACK callback,DWORD userData)
{
    update2GUICallback=callback;
    m_userData=userData;
}

