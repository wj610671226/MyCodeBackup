#ifndef CAMERACLIENT_H
#define CAMERACLIENT_H

extern "C" {
#include <stdbool.h>

}

#include "sendioctrlmsgqueue.h"
#include "h264decoder.h"
#include "sendioctrlmsgqueue.h"

#define CONNECTION_MODE_NONE -1
#define CONNECTION_MODE_P2P 0
#define CONNECTION_MODE_RELAY 1
#define CONNECTION_MODE_LAN 2

#define CONNECTION_STATE_NONE 0
#define CONNECTION_STATE_CONNECTING 1
#define CONNECTION_STATE_CONNECTED 2
#define CONNECTION_STATE_DISCONNECTED 3
#define CONNECTION_STATE_UNKNOWN_DEVICE 4
#define CONNECTION_STATE_WRONG_PASSWORD 5
#define CONNECTION_STATE_TIMEOUT 6
#define CONNECTION_STATE_UNSUPPORTED 7
#define CONNECTION_STATE_CONNECT_FAILED 8

#define REAL_AUDIO_OUT
#define AVRECVFRAMEDATA2

#define RECV_VIDEO_BUFFER_SIZE 1280 * 720 * 3
#define RECV_AUDIO_BUFFER_SIZE 1280
#define SPEEX_FRAME_SIZE 160
#define MAX_IOCTRL_BUFFER_SIZE 1024
#define kQualityMonitorPeriod 60000
#define SNAPSHOTIMAGEBUFFER_SIZE 10240
#define DONE 1
#define NOTDONE 0


typedef  enum
{
    IPHONEDEVICEGEN_1=0,
    IPHONEDEVICEGEN_2,
    IPHONEDEVICEGEN_3,
    IPHONEDEVICEGEN_4,
    IPHONEDEVICEGEN_5,
    IPHONEDEVICEGEN_6,
    IPHONEDEVICEGEN_7,
    IPHONEDEVICEGEN_UNKNOWN

}IPHONEDEVICE_GENERATION;

typedef void (*UPDATEVIDEO2GUICALLBACK)(RGBData* rgbData,DWORD userData);

class CameraClient
{



public:
    CameraClient(char *uid_ ,char * name_ ,char * viewAcc_ ,char *viewPwd_);
    ~CameraClient();


    int              connectionState; //连接状态.
    bool             updatingYUVFrame;
    bool             connectState;



public:

    static void initIOTC();
    static void uninitIOTC();


    void connect();
    void stopConnectedSession();


    void startShow();
    void stopShow();

    void startSoundToPhone();
    void stopSoundToPhone();
    void startSoundToDevice();
    void stopSoundToDevice();

    void sendIOCtrl(int controlCMD ,char  *buff,int size);

    static unsigned int getTickCount();

    void setupUpdateGUICallback(UPDATEVIDEO2GUICALLBACK callback,DWORD userData);
private:

    static void* doStartThread(void* arg);
    static void* startSendIOCtrlFromMsgQueueThread(void* arg);
    static void* startRecvIOCtrlFromDeviceThread(void* arg);

    static void* startRecvVideoThread(void* arg);

    void startConnection();
    void sendIOCtrlThread();
    void recvIOCtrlThread();

    void doRecvVideo();

    int detachThreadCreate(pthread_t *thread, void * start_routine, void *arg);


    void updateImageData(RGBData* rgbData);

private:


    int              sessionID;
    int              sessionMode;
    int              sessionState;
    int              sessionID4ConnStop;

    int              avChannel;

    int              audioCodec;
    int              nAvResend;
    int              avIndex;

    int              connFailErrCode;

    int              chIndexForSendAudio; //发送Audio通道。
    int              avIndexForSendAudio; //sendAudio index

    bool             isRunningRecvAudioThread;
    bool             isRunningRecvVideoThread;
    bool             isRunningSendIOCtrlThread;
    bool             isRunningRecvIOCtrlThread;
    bool             isRunningCheckingThread;

    bool             isConnectingServer;
    bool             isRunningSendAudio;


    char             recvIOCtrlBuff[MAX_IOCTRL_BUFFER_SIZE];


    char             name[16];
    char             uid[20];
    char             viewAcc[16];
    char             viewPwd[16];

    SendIOCtlMsgQueue*  iocontrollMsgQueue;

    UPDATEVIDEO2GUICALLBACK     update2GUICallback;
    DWORD                       m_userData;

};






#endif // CAMERACLIENT_H
