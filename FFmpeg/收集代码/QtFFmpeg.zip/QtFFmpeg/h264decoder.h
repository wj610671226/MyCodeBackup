#ifndef H264DECODER_H
#define H264DECODER_H


#import "DecodeH264Data_YUV.h"

extern "C" {

#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
}

#if !defined(MIN)
    #define MIN(A,B)	((A) < (B) ? (A) : (B))
#endif
#if !defined(MAX)
    #define MAX(A,B)	((A) > (B) ? (A) : (B))
#endif
#if !defined(ABS)
    #define ABS(A)	((A) < 0 ? (-(A)) : (A))
#endif


typedef unsigned long   DWORD;



class H264Decoder
{
public:
    H264Decoder();
    ~H264Decoder();


    int DecodeH264Frames(unsigned char* inputBuffer ,int aLength,RGBData* outputRGBData);

private:

    int         pictureWidth;
    AVCodec*        pCodec;
    AVCodecContext* pCodecCtx;
    AVFrame*        pVideoFrame;
    AVPacket        pAvPackage;
    int             setRecordResolveState;


     AVPicture                   outPicture;
     struct SwsContext *         img_convert_ctx;

    void copyDecodedFrame(unsigned char *src, unsigned char *dist,int linesize, int width, int height);

};



#endif // H264DECODER_H
